---
layout: default
title: Appendices
nav_order: 1
---


# Appendices

[Debugging and common errors](2_debugging.md)\
[C++ basics](3_basic_cpp.md)\
[Object-oriented programming basics](4_basic_oop.md)
