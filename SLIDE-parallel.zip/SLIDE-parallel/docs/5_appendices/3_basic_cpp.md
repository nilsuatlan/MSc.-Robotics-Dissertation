---
layout: default
title: C++ basics
nav_order: 3
---


# C++ basics

C++ is infamous for being an expert-friendly language; however, if you could compile the code on your computer then you finished the main part. Editing code should be simple and we are doing our best to make it simpler. 