The files in this folder are mostly taken and adapted from: 

https://github.com/lefticus/cpp_weekly/tree/master/cmake

Currently, they may or may not be in use. 

CPM is obtained from https://github.com/cpm-cmake/CPM.cmake
