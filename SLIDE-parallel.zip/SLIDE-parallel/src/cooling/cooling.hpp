/*
 * modules.hpp
 *
 * to include available module headers.
 *
 *  Created on: 04 Nov 2022
 *   Author(s): Jorn Reniers, Volkan Kumtepeli
 *
 */


#pragma once

#include "CoolSystem_HVAC.hpp"
#include "CoolSystem_open.hpp"