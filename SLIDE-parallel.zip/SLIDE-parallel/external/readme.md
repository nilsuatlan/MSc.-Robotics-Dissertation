External libraries SLIDE use. 

All external libraries are directly included in the external folder to ease build process. 

* Eigen: Eigen is a great MPL2-licensed linear algebra library. We included this library by removing folders regarding test, documents etc and only changed its CMakeLists.txt to reflect these removals and several options. For further information [see](http://eigen.tuxfamily.org/index.php?title=Licensing_FAQ).